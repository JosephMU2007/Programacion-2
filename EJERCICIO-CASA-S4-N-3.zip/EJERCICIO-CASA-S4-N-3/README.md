# EJERCICIO-CASA-S4-N-3

Ejercicio de Programación II sobre clases, objetos, métodos y atributos `static`.

## Archivos
- `src/Servidor.java`: clase principal del ejercicio.
- `src/Main.java`: crea tres servidores y prueba la activación y los contadores.

## Datos de prueba usados
- ServidorPrincipal — 192.168.10.15
- ServidorDatos — 192.168.10.25
- ServidorRespaldo — 192.168.10.35

## Resultado esperado
- Total de servidores creados: 3
- Total de servidores activos: 2
